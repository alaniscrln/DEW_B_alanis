class Creature{
    constructor(type, race){
        this.type = type;
        this.race = race;
    }

}